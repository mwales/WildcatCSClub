#!/usr/bin/env -S python3 -u

import random, os, time, struct

gNames = [ "Kylo Ren",
           "General Leia",
           "Luke Skywalker",
           "Rey",
           "Poe",
           "Finn" ]

gPics = {}

gPicWidth = 50
gPicHeight = 25

def centerString(s, l):
	begin = (l - len(s)) // 2
	retData = (" " * begin) + s + (" " * l)
	return retData[0:l]

def loadPictures():
	picData = open("pictures.ans","r").read().split("\n")
	curLine = 0

	for person in gNames:
		gPics[person] = picData[curLine: curLine + gPicHeight]
		curLine += gPicHeight

def printVersus(char1, char2):
	for i in range(0,gPicHeight):
		if (i == (gPicHeight // 2)):
			print("{}  -VS-  {}".format(gPics[char1][i], gPics[char2][i]))
		else:
			print("{}        {}".format(gPics[char1][i], gPics[char2][i]))
	
	print("")
	print("{}        {}".format(centerString(char1, gPicWidth), centerString(char2, gPicWidth)))

def win():
	os.system("cat flag.txt")
	time.sleep(10)

def loser(name):
	cowFiles = [ "leia.cow", "leia2.cow", "ackbar.cow", "baby_yoda.cow", 
	             "ewok.cow", "r2d2-c3po.cow", "atst-atat.cow" ]
	cowFile = "./cows/" + random.choice(cowFiles)
	os.system('/usr/games/cowsay -f {} "{} is a loser.  lolz"'.format(cowFile, name))
	time.sleep(10)

def battle(char1, char2):
	char1Life = 100
	char2Life = 100

	while( (char1Life > 0) and (char2Life > 0) ):
		dmg1 = random.randint(1,50)
		dmg2 = random.randint(1,50)

		char1Life -= dmg1
		char2Life -= dmg2

		print("{} attacks {} for {}, leaving him with only {} life left".format(char1, char2, dmg1, char1Life))
		print("{} attacks {} for {}, leaving him with only {} life left".format(char2, char1, dmg2, char2Life))

	if (char1Life > 0):
		print("  {} wins!\n".format(char1))
		retVal = 1
	elif (char2Life > 0):
		print("  {} wins!\n".format(char2)) 
		retVal = 2
	else:
		print("  Everyone dies!\n")
		retVal = 0 

	time.sleep(.25)
	return retVal

def main():
	randBytes = os.urandom(4)
	(seedVal) = struct.unpack("I",randBytes)
	random.seed(seedVal)
	
	loadPictures()

	winStreak = 0
	numLosses = 0

	name = input("What is your name challenger?\n")

	while( (winStreak < 7) and (numLosses < 3) ):

		char1 = random.choice(gNames)
		shortList = gNames[:]
		shortList.remove(char1)
		char2 = random.choice(shortList)

		printVersus(char1, char2)

		selection = input("Who Wins?  1 = {}, 2 = {}, 0 = Everyone dies, q = quit\n".format(char1, char2))

		if (selection == "q"):
			break;

		winner = battle(char1, char2)

		if (winner == int(selection)):
			winStreak += 1
			print("Current win streak: {}".format(winStreak))
		else:
			winStreak = 0
			numLosses += 1
			print("Not looking good {}, your win streak just got reset to 0.  Rekt!".format(name))

	if (winStreak >= 7):
		win()

	if (numLosses >= 3):
		loser(name)

	print("Goodbye")

if (__name__ == "__main__"):
	main()
